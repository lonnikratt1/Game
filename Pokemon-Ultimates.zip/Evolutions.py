from replit import db
def Evolve():
        if db['PokemonName'] == 'Litwick' and db['EeveeLv'] > 24:
                db['PokemonName'] = 'Lampent'
                print("Your Pokemon evolved into a Lampent! ")
        elif db['PokemonName'] == 'Lampent' and db['EeveeLv'] > 34:
                db['PokemonName'] = 'Chandelure'
                print("Your Pokemon evolved into a Chandelure! ")
        elif db['PokemonName'] == 'Caikit' and db['EeveeLv'] > 20:
                db['PokemonName'] = 'Caikatt'
                print("Your Pokemon evolved into a Caikatt! ")
        elif db['PokemonName'] == 'Caikatt' and db['EeveeLv'] > 40:
                db['PokemonName'] = 'Caikatat'
                print("Your Pokemon evolved into a Caikatat! ")
        elif db['PokemonName'] == 'Chocleon' and db['EeveeLv'] > 20:
                db['PokemonName'] = 'Cocoaleon'
                print("Your Pokemon evolved into a Cocoaleon! ")
        elif db['PokemonName'] == 'Cocoaleon' and db['EeveeLv'] > 40:
                db['PokemonName'] = 'Choclameleon'
                print("Your Pokemon evolved into a Choclameleon! ")
        elif db['PokemonName'] == 'Soadapup' and db['EeveeLv'] > 20:
                db['PokemonName'] = 'Softipop'
                print("Your Pokemon evolved into a Sofipop! ")
        elif db['PokemonName'] == 'Softipop' and db['EeveeLv'] > 40:
                db['PokemonName'] = 'Poplipup'
                print("Your Pokemon evolved into a Poplipup! ")
        elif db['PokemonName'] == 'Piethon' and db['EeveeLv'] > 25:
                db['PokemonName'] = 'Jaavaa'
                print("Your Pokemon evolved into a Jaavaa! ")
        elif db['PokemonName'] == 'Jaavaa' and db['EeveeLv'] > 43:
                db['PokemonName'] = 'Cei++'
                print("Your Pokemon evolved into a Cei++! ")
        elif db['PokemonName'] == 'Onix' and db['EeveeLv'] > 28:
                db['PokemonName'] = 'Steelix'
                print("Your Pokemon evolved into a Steelix! ")
        elif db['PokemonName'] == 'Squirtle' and db['EeveeLv'] > 15:
                db['PokemonName'] = 'Wartortle'
                print("Your Pokemon evolved into a Wartortle! ")
        elif db['PokemonName'] == 'Wartortle' and db['EeveeLv'] > 32:
                db['PokemonName'] = 'Blastoise'
                print("Your Pokemon evolved into a Blastoise! ")
        elif db['PokemonName'] == 'Charmander' and db['EeveeLv'] > 16:
          db['PokemonName'] = 'Charmeleon'
          print('Your pokemon evolved into an Charmeleon!')
        elif db['PokemonName'] == 'Charmeleon' and db['EeveeLv'] > 36:
          db['PokemonName'] = 'Charizard'
          print('Your pokemon evolved into an Charizard!')
        elif db['PokemonName'] == 'Bulbasaur' and db['EeveeLv'] > 16:
          db['PokemonName'] = 'Ivysaur'
          print('Your pokemon evolved into an Ivysaur!')
        elif db['PokemonName'] == 'Ivysaur' and db['EeveeLv'] > 36:
          db['PokemonName'] = 'Venusaur'
          print('Your pokemon evolved into a Venusaur!')
        elif db['PokemonName'] == 'Sandshrew' and db['EeveeLv'] > 17:
          db['PokemonName'] = 'Sandslash'
          print('Your pokemon evolved into a Sandslash!')
        elif db['PokemonName'] == 'Psyduck' and db['EeveeLv'] > 30:
          db['PokemonName'] = 'Golduck'
          print('Your pokemon evolved into a Golduck!')
        elif db['PokemonName'] == 'Pidgey' and db['EeveeLv'] > 15:
          db['PokemonName'] = 'Pidgeotto' 
          print('Your pokemon evolved into a Pidgeotto!')
        elif db['PokemonName'] == 'Caterpie' and db['EeveeLv'] > 10:
          db['PokemonName'] = 'Metapod'
          print('Your pokemon evolved into a Metapod! ')
        elif db['PokemonName'] == 'Metapod' and db['EeveeLv'] > 20:
          db['PokemonName'] = 'Butterfree'
          print('Your pokemon evolved into a Butterfree! ')
        elif db['PokemonName'] == 'Pikachu' and db['EeveeLv'] > 23:
          db['PokemonName'] = 'Raichu'
          print('Your pokemon evolved into a Raichu! ')
        elif db['PokemonName'] == 'Scribbly' and db['EeveeLv'] > 20:
          db['PokemonName'] = 'Sketchy'
          print('Your pokemon evolved into Sketchy! ')
        elif db['PokemonName'] == 'Sketchy' and db['EeveeLv'] > 50:
          db['PokemonName'] = 'ColoredHue'
          print('Your pokemon evolved into the SECRET RARE ColoredHue! ')
        elif db['PokemonName'] == 'Edgy' and db['EeveeLv'] > 69:
          db['PokemonName'] = "Sus"
           
        
        elif db['PokemonName'] == 'Amogus' and db['EeveeLv'] > 50:
          db['PokemonName'] = 'Sussy Baka'
          print('Your pokemon evolved into the SECRET RARE Sussy Baka! ')
        elif db['PokemonName'] == 'Leafeon' and db['EeveeLv'] > 250:
          db['PokemonName'] = 'Mega-Leafeon'
          print('Your pokemon evolved into Mega-Leafeon!')
        elif db['PokemonName'] == 'Mega-Leafeon' and db['EeveeLv'] > 750:
          db['PokemonName'] = 'Rainbow-Leafeon GX'
          print('Your pokemon evolved into Rainbow-Leafeon GX!')
        elif db['PokemonName'] == 'Noivern' and db['EeveeLv'] > 1000:
          db['PokemonName'] = 'Colored-Noivern'
          print('Your pokemon evolved into Colored-Noivern!')
          


  