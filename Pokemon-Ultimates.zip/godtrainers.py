from colorama import *
TheBestCoders = {
  f'{Fore.RED}Co{Fore.LIGHTYELLOW_EX}lo{Dunce.LIGHTGREEN_EX}re{Dunce.BLUE}dH{Fore.MAGENTA}ue{Fore.RESET}': ['Noivern', 'Inteleon', 'Steelix', 'Articuno', 'Quaxly', 'Colored-Noivern'],
        
  'Ash Ketchum': ['Pikachu', 'Squirtle', 'Bulbasaur', 'Charmander', 'Pidgeotto', 'Butterfree'], 

  'Steven': ['Lunala', 'Solgaleo', 'Reshiram', 'Zekrom', 'Arceus', 'Articuno'], # I will beat this loser. He just has a couple decent pokemon

  'Gary': ['Blastoise', 'Arcanine', 'Umbreon', 'Electivire', 'Tyranitar', 'Krabby'],

  'Eevee Kid': ['Eevee', 'Jolteon'],

  'Pikachu Kid': ['Pikachu', 'Raichu'],

  'Mecha Micah': ['Porygon2', 'Voltorb', 'Rhyhorn'],

  'Misty': ['Psyduck', 'Horsea', 'Vaporeon', 'Poliwag'],
  
  'Brock': ['Onix', 'Steelix'],
  
  'Jessie': ['Arbok'],

  'James': ['Weezing'],

  'SuperStriker16': ["Striker's-Charizard", 'Jolteon', 
  'Articuno', 'Super-Dunce', 'Bulbasaur', 'Dragonite'],

  'S1lveredPrism': ['Leafeon', 'N/A', 'N/A', 'N/A', 'N/A', 'Silvered-Leafeon'],
}