import replit
import time
def affirm():
  input('Click [Enter] to continue ')
def pause(t):
  time.sleep(t)
def clear():
  replit.clear()